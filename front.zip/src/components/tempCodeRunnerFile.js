// const getRole = async () => {
  //   let dataa = await axios.get(
  //     `http://localhost:4500/api/v1/getuserdetail/${email}`
  //   );
  //   console.log(dataa);
  //   setRolee(dataa[0].role);
  //   console.log(dataa[0].role)
  // }
  // useEffect(
  //   getRole
  // , [])